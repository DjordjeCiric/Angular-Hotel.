export class Smestaj {
    naziv: string | undefined;
    brojKreveta: number | undefined;
    cenaPoNoci: number | undefined;

  }
  