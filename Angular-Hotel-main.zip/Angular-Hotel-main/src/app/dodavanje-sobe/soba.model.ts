export class Soba {
    constructor(
      public id: number,
      public ime: string,
      public brojKreveta: number,
      public cenaPoNoci: number
    ) {}
  }